import React from 'react'

export default function AddCategory() {
  return (
    <div>
      
    </div>
  )
}
