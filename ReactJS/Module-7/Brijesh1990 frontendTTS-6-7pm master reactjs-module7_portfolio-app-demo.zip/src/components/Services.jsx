import React from 'react';
import { Container } from 'react-bootstrap';

export default function Services() {
  return (
    <div>
        
    <Container className='p-5 bg-light'>
     
    <h1 className='text-center'>This is Our Services</h1>
    </Container>
     

      
    </div>
  )
}
