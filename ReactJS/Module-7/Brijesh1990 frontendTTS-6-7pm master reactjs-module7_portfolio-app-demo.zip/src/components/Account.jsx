import React from 'react';
import { Container } from 'react-bootstrap';

export default function Account() {
  return (
    <div>
          
    <Container className='p-5 bg-light'>
     
    <h1 className='text-center'>This is Account</h1>
    </Container>
     
    </div>
  )
}
